# 引入必要的库
import os  # 用于文件和操作系统路径操作
import requests  # 用于发送HTTP请求获取数据
import pandas as pd  # 用于数据处理和存储
from datetime import datetime, timedelta  # 用于日期和时间操作
import schedule  # 用于设置定时任务
import time  # 用于控制时间间隔

# 高德地图 API 密钥，用于访问交通数据
API_KEY = "22b243f95401b4de77b87bde34b5bcfc"

# 定义目标地点列表，包括路名、经度和纬度
locations = [
    # 示例：每个路段包含路名、经度和纬度
    {"路": "复兴门外大街", "经度": 116.3525, "纬度": 39.9075},
    {"路": "复兴门南大街", "经度": 116.3575, "纬度": 39.9},
    # ... 其他路段数据
]
location_data = {
    "路": [
        "复兴门外大街", "复兴门南大街", "复兴门", "阜成门外大街", "西单", "西四北大街", "北长街", "东华门大街",
        "南河沿大街", "王府井大街", "北京东方广场", "东单", "崇文门内大街", "东四南大街", "建国门内大街",
        "建国门", "东四十条"
    ],
    "经度": [116.355, 116.366, 116.357, 116.353, 116.381, 116.386, 116.403, 116.405, 116.408, 116.411, 116.418,
                116.425, 116.428, 116.429, 116.433, 116.435, 116.438],
    "纬度": [39.912, 39.915, 39.907, 39.915, 39.910, 39.918, 39.919, 39.924, 39.922, 39.922, 39.924, 39.920, 39.915,
                39.917, 39.915, 39.911, 39.920]
}
# 交通状态映射字典，用于将状态数值转换为中文描述
status_mapping = {
    0: "严重拥堵",
    1: "拥堵",
    2: "缓行",
    3: "畅通"
}

# 数据保存路径，用于存储采集到的交通数据
save_file = r'./scrape data/data/traffic_data7.csv'

# 定义函数，用于获取指定地点的交通状态数据
def fetch_traffic_status():
    data_list = []  # 存储获取的交通数据
    for  index, road_name in enumerate(location_data["路"]):
        # 设置API请求的URL和参数
        url = f"https://restapi.amap.com/v3/traffic/status/road"
        params = {
            "key": API_KEY,  # API密钥
            "city": "北京",  # 城市
            "name": road_name  # 路段名称
        }

        # 捕获HTTP请求错误，避免程序因单次请求失败而中断
        try:
            print('response')
            response = requests.get(url, params=params, timeout=10)  # 发送GET请求，设置超时时间
            response.raise_for_status()  # 检查响应状态码
            traffic_data = response.json()  # 将响应数据转换为JSON格式
            # 打印返回内容以进行调试
            print(f"Response for {road_name}: {traffic_data}")

            # 检查API返回的数据是否有效
            if traffic_data["status"] == "1" and "trafficinfo" in traffic_data:
                traffic_info = traffic_data["trafficinfo"]
                now = datetime.now()
                # 如果返回的交通信息包含道路数据
                if "roads" in traffic_info:
                    for road in traffic_info["roads"]:
                        data_list.append({
                            "时间": now.strftime("%Y-%m-%d %H:%M:%S"),  # 当前时间
                            "路": road["name"],  # 路段名称
                            "状态": status_mapping.get(int(road["status"]), "未知"),  # 状态描述
                            "经度": location_data["经度"][index],  # 经度
                            "纬度": location_data["纬度"][index],  # 纬度
                            "状态数值": int(road["status"]),  # 状态数值
                            "小时": now.strftime("%H"),
                            "分钟": now.strftime("%M")
                        })
                else:
                    # 如果返回的是综合评估信息
                    evaluation = traffic_info.get("evaluation", {})
                    now = datetime.now()
                    data_list.append({
                        "时间": now.strftime("%Y-%m-%d %H:%M:%S"),
                        "路": road_name,
                        "状态": status_mapping.get(int(evaluation.get("status", 0)), "未知"),
                        "经度": location_data["经度"][index],
                        "纬度": location_data["纬度"][index],
                        "状态数值": int(evaluation.get("status", 0)),
                        "小时": now.strftime("%H"),
                        "分钟": now.strftime("%M")
                    })
            else:
                # 当API未返回有效的交通数据时打印调试信息
                print(f"No valid trafficinfo for {road_name} - Status: {traffic_data.get('status')}, Info: {traffic_data.get('info')}")
            time.sleep(10)

        except requests.RequestException as e:
            # 捕获网络错误并打印相关信息
            print(f"Error fetching data for {road_name}: {e}")
            continue  # 跳过当前路段，继续处理下一个路段

    # 返回包含所有地点交通状态的数据集
    return pd.DataFrame(data_list)

# 定义定时任务，用于定期获取交通数据并保存
def job():
    traffic_df = fetch_traffic_status()  # 获取交通数据
    if not traffic_df.empty:  # 检查数据是否为空
        # 检查文件是否存在，以决定是否写入表头
        write_header = not os.path.exists(save_file)
        traffic_df.to_csv(save_file, mode="a", index=False, header=write_header, encoding="utf-8-sig")
        print(f"Data appended to {save_file}")  # 打印保存成功信息
    else:
        print("No data collected for this run.")  # 数据为空时提示

# 设置定时任务，每隔2分钟运行一次
schedule.every(2).minutes.do(job)

# 持续运行任务，设定运行时间为10小时 Run the task continuously and set the running time to 10 hours
start_time = datetime.now()  # 开始时间
end_time = start_time + timedelta(hours=10)  # 结束时间 End time

while datetime.now() < end_time:  # 在设定时间范围内运行 Run within a set time range
    schedule.run_pending()  # 检查并运行定时任务
    time.sleep(1)  # 每秒检查一次任务

# 任务完成后打印提示
print("10 hours of data scraping completed. Exiting.")
