import pandas as pd

# 定义数据文件路径
file_path = r"/templates/data\traffic_data6.csv"

# 读取数据
try:
    data = pd.read_csv(file_path)
    print("Data loaded successfully!")
except Exception as e:
    print(f"Error loading data: {e}")
    exit()

# 检查数据结构
print("Original Data Info:")
print(data.info())

# 清洗数据：提取唯一的路段名称及其经纬度
cleaned_data = data[['路', '经度', '纬度']].drop_duplicates().reset_index(drop=True)

# 检查清洗后的数据
print("Cleaned Data Preview:")
print(cleaned_data.head())

# 保存清洗后的数据到新文件
output_file_path = r"/templates/data\cleaned_traffic_data.csv"
try:
    cleaned_data.to_csv(output_file_path, index=False, encoding="utf-8-sig")
    print(f"Cleaned data saved to {output_file_path}")
except Exception as e:
    print(f"Error saving cleaned data: {e}")
