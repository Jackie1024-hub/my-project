import pandas as pd

# Load the uploaded CSV file
file_path = '/mnt/data/traffic_data1.0.csv'
data = pd.read_csv(file_path)

# Rename columns and rearrange
columns_order = ['时间', '路', '状态', '经度', '纬度', '状态数值', '小时', '分钟']
data = data[columns_order]

# Export the modified data to a new CSV file
output_path = '/mnt/data/modified_traffic_data.csv'
data.to_csv(output_path, index=False, encoding='utf-8-sig')

output_path
