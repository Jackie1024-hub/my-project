from flask import Flask, render_template
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from plotly.subplots import make_subplots
from plotly.graph_objects import Scattermapbox, Bar
import plotly.graph_objects as go

app = Flask(__name__)
save_file = r'./scrape data/data/traffic_data7.csv'

# 定义预测时间（4 时和 10 时）
future_times = [
    {"小时": 1, "分钟": 0},
    {"小时": 10, "分钟": 0}
]
filtered_df = None
future_df = None
def get_future():
    global filtered_df
    global future_df
    try:
        # 从 CSV 文件读取数据
        df = pd.read_csv('traffic_data.csv')

    except FileNotFoundError:
        return "Error: 'traffic_data.csv' file not found."
    except Exception as e:
        return f"Error loading data: {e}"

    # 检查数据是否包含必要列
    required_columns = {"经度", "纬度", "小时", "分钟", "状态数值", "路", "状态"}
    if not required_columns.issubset(df.columns):
        return "Error: Missing required columns in the dataset."

    # 使用统一的数据集
    filtered_df = df.copy()

    # 特征与目标
    X = filtered_df[["经度", "纬度", "小时", "分钟"]]
    y = filtered_df["状态数值"]

    # 数据分割
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 模型训练（分类模型）
    model = RandomForestClassifier(n_estimators=100, max_depth=20, random_state=42)
    model.fit(X_train, y_train)


    # 路段位置数据
    location_data = {
        "路": [
            "复兴门外大街", "复兴门南大街", "复兴门", "阜成门外大街", "西单", "西四北大街", "北长街", "东华门大街",
            "南河沿大街", "王府井大街", "北京东方广场", "东单", "崇文门内大街", "东四南大街", "建国门内大街",
            "建国门", "东四十条"
        ],
        "经度": [116.355, 116.366, 116.357, 116.353, 116.381, 116.386, 116.403, 116.405, 116.408, 116.411, 116.418,
                 116.425, 116.428, 116.429, 116.433, 116.435, 116.438],
        "纬度": [39.912, 39.915, 39.907, 39.915, 39.910, 39.918, 39.919, 39.924, 39.922, 39.922, 39.924, 39.920, 39.915,
                 39.917, 39.915, 39.911, 39.920]
    }
    locations = pd.DataFrame(location_data)

    # 预测未来交通状态
    future_df = pd.DataFrame(future_times).merge(locations, how="cross")
    future_df["状态数值预测"] = model.predict(future_df[["经度", "纬度", "小时", "分钟"]])

    # 定义状态的映射字典
    status_mapping = {0: "严重拥堵", 1: "拥堵", 2: "缓行", 3: "畅通"}
    future_df["状态预测"] = future_df["状态数值预测"].apply(lambda x: status_mapping[x])

    
@app.route('/')
def index(line_fig=None):
    global filtered_df
    global future_df
    if future_df is None:
        get_future()
    else:
        try:
            # 从 CSV 文件读取数据
            df = pd.read_csv(save_file)
        except FileNotFoundError:
            return "Error: 'traffic_data.csv' file not found."
        except Exception as e:
            return f"Error loading data: {e}"

        # 检查数据是否包含必要列
        required_columns = {"经度", "纬度", "小时", "分钟", "状态数值", "路", "状态"}
        if not required_columns.issubset(df.columns):
            return "Error: Missing required columns in the dataset."

        # 使用统一的数据集
        filtered_df = df.copy()
    # 地图可视化
    fig = make_subplots(rows=1, cols=1, specs=[[{"type": "mapbox"}]])

    # 添加实时数据
    fig.add_trace(Scattermapbox(
        lat=filtered_df["纬度"],
        lon=filtered_df["经度"],
        mode='markers',
        marker=dict(
            size=10,
            color=filtered_df["状态数值"],
            colorscale=[
                [0, "red"],  # 严重拥堵
                [0.33, "orange"],  # 拥堵
                [0.66, "yellow"],  # 缓行
                [1, "green"]  # 畅通
            ],
            cmin=0,
            cmax=3,
            showscale=True
        ),
        text=filtered_df["路"] + " 状态: " + filtered_df["状态"],
        name="实时交通流"
    ))

    # 添加未来数据
    for t, hour in zip(future_times, ["4 时", "10 时"]):
        subset = future_df[(future_df["小时"] == t["小时"]) & (future_df["分钟"] == t["分钟"])]
        fig.add_trace(Scattermapbox(
            lat=subset["纬度"],
            lon=subset["经度"],
            mode='markers',
            marker=dict(
                size=10,
                color=subset["状态数值预测"],
                colorscale=[
                    [0, "red"],  # 严重拥堵
                    [0.33, "orange"],  # 拥堵
                    [0.66, "yellow"],  # 缓行
                    [1, "green"]  # 畅通
                ],
                cmin=0,
                cmax=3,
                showscale=True
            ),
            text=subset["路"] + " 状态: " + subset["状态预测"],
            name=hour
        ))
    # 更新地图布局
    fig.update_layout(
        mapbox=dict(
            style="carto-positron",  # 地图样式
            center=dict(lat=39.91, lon=116.4),  # 设置地图初始中心点
            zoom=12.0  # 设置初始缩放级别
        ),
        title="Beijing real-time and predicted traffic flow visualization",  # 设置地图标题
        width=2100,  # 增加地图宽度
        height=600,  # 设置地图高度
        showlegend=False,  # 隐藏图例
        updatemenus=[
            dict(
                type="buttons",
                direction="down",  # 按钮垂直排列
                x=0.02,  # 按钮位置靠左
                y=0.9,  # 按钮位置靠上
                buttons=[
                    dict(
                        label="real time",
                        method="update",
                        args=[{"visible": [True, False, False]}]  # 显示实时数据
                    ),
                    dict(
                        label="1 hour",
                        method="update",
                        args=[{"visible": [False, True, False]}]  # 显示4时预测数据
                    ),
                    dict(
                        label="10 hour",
                        method="update",
                        args=[{"visible": [False, False, True]}]  # 显示10时预测数据
                    ),
                    dict(
                        label="Display scale",
                        method="update",  # 更新图层属性
                        args=[{
                            "marker.showscale": True  # 显示颜色比例尺
                        }]
                    ),
                    dict(
                        label="Hide scale",
                        method="update",  # 更新图层属性
                        args=[{
                            "marker.showscale": False  # 隐藏颜色比例尺
                        }]
                    )
                ],
                showactive=True,  # 激活的按钮高亮显示
                bgcolor="rgba(200, 200, 200, 0.8)"  # 设置按钮背景颜色
            )
        ],
        dragmode="zoom",  # 启用拖动缩放功能
        hovermode="closest",  # 启用悬停功能，显示最近点的信息
        paper_bgcolor='rgba(0,0,0,0)',  # 整个图表背景透明
        plot_bgcolor='rgba(0,0,0,0)',  # 图表内容区域背景透明
        margin=dict(l=0, r=0, t=0, b=0)  # 减少多余空白，去掉边距
    )

    # 数据分析图：实时与预测折线图
    # 实时数据
    realtime_avg_congestion = filtered_df.groupby("路")["状态数值"].mean().reset_index()
    realtime_avg_congestion["数据类型"] = "实时"

    # 预测数据
    predicted_avg_congestion = future_df.groupby("路")["状态数值预测"].mean().reset_index()
    predicted_avg_congestion["数据类型"] = "预测"

    # 折线图
    line_fig = go.Figure()

    # 添加实时数据折线
    line_fig.add_trace(go.Scatter(
        x=realtime_avg_congestion["路"],
        y=realtime_avg_congestion["状态数值"],
        mode="lines+markers",
        line=dict(color="blue", dash="solid"),
        marker=dict(size=8),
        name="Real-time data"
    ))

    # 添加预测数据折线
    line_fig.add_trace(go.Scatter(
        x=predicted_avg_congestion["路"],
        y=predicted_avg_congestion["状态数值预测"],
        mode="lines+markers",
        line=dict(color="red", dash="dash"),
        marker=dict(size=8),
        name="Prediction data"
    ))

    # 更新折线图布局
    line_fig.update_layout(
        xaxis=dict(
            title=dict(
                text="Street",
                font=dict(size=16)  # 调整 x 轴标题字体大小
            ),
            tickangle=45,
            tickfont=dict(size=12)  # 调整 x 轴刻度字体大小
        ),
        yaxis=dict(
            title=dict(
                text="Congestion Status",
                font=dict(size=16)  # 调整 y 轴标题字体大小
            ),
            range=[0, 3],
            tickvals=[0, 1, 2, 3],
            ticktext=["smooth", "slow traffic", "congested", "severely congested"],
            tickfont=dict(size=12)  # 调整 y 轴刻度字体大小
        ),
        legend=dict(
            title=dict(
                text="Data Types",
                font=dict(size=14)  # 调整图例标题字体大小
            ),
            font=dict(size=12),  # 调整图例内容字体大小
            orientation="h",
            x=0.5,
            y=1.1,
            xanchor="center"
        ),
        font=dict(size=17),  # 调整全局字体大小
        width=2200,
        height=600,
        paper_bgcolor='rgba(0,0,0,0)',  # 整个图表背景透明
        plot_bgcolor='rgba(255,255,255,0.8)',  # 图表内容区域白色半透明
    )

    # 渲染模板
    return render_template(
        'traffic.html',
        map_plot=fig.to_html(full_html=False),
        line_plot=line_fig.to_html(full_html=False)
    )


if __name__ == '__main__':
    app.run(debug=True)