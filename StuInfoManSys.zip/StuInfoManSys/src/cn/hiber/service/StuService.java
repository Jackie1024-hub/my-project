package cn.hiber.service;

import java.util.List;

import cn.hiber.dao.StudentDao;
import cn.hiber.dao.UserDao;
import cn.hiber.dao.impl.StudentDaoImpl;
import cn.hiber.dao.impl.UserDaoImpl;
import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;

public class StuService {
	
	private StudentDao studentDao = new StudentDaoImpl();
	
		//����ѧ��
		public boolean addStuent(StudentInfo student) {
			return studentDao.addStu(student);
		}
	
		//ͨ��������ѯѧ��
		public StudentInfo findStuBySname(String sname) {
			return studentDao.findStuBySname(sname);
		}
		
		//ͨ��������ѯѧ��
		public StudentInfo findStuBySnumber(String snumber) {
			return studentDao.findStuBySnumber(snumber);
		}
		
		//��ѯ����ѧ��
		public List<StudentInfo> findAllStu() {
			return studentDao.findAllStu();
		}
		
		//�޸�ѧ����Ϣ
		public boolean updateStu(StudentInfo student) {
			return studentDao.updateStu(student);
		}
		
		//�޸�ѧ����Ϣ
		public boolean deleteStu(StudentInfo student) {
			return studentDao.deleteStu(student);
		}

}
