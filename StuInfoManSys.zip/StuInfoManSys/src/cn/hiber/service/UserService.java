package cn.hiber.service;

import java.util.List;

import cn.hiber.dao.StudentDao;
import cn.hiber.dao.UserDao;
import cn.hiber.dao.impl.UserDaoImpl;
import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;

public class UserService {
	
	private UserDao userDao = new UserDaoImpl();
	
	//��¼
		public UserInfo login(UserInfo user) {
			List<UserInfo> list = userDao.findUser(user);
			if(list.size()>0) {
				return list.get(0);
			}
			return null;
		}
	
	//ע��
		public boolean register(UserInfo user) {
			return userDao.addUser(user);
		}
		
	//�޸�����
		public boolean updateUser(UserInfo user) {
			return userDao.updateUser(user);
		}

}
