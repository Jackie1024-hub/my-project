package cn.hiber.entity;

/**
 * StudentInfo entity. @author MyEclipse Persistence Tools
 */

public class StudentInfo implements java.io.Serializable {

	// Fields

	private Long sid;
	private String sname;
	private String snumber;
	private String ssex;
	private String sage;
	private String sclass;
	private String snativeplace;
	private String snation;
	private String scollege;
	private String sbeiyong01;
	private String sbeiyong02;

	// Constructors

	/** default constructor */
	public StudentInfo() {
	}

	/** minimal constructor */
	public StudentInfo(String sname, String snumber, String ssex, String sage,
			String sclass) {
		this.sname = sname;
		this.snumber = snumber;
		this.ssex = ssex;
		this.sage = sage;
		this.sclass = sclass;
	}

	/** full constructor */
	public StudentInfo(String sname, String snumber, String ssex, String sage,
			String sclass, String snativeplace, String snation,
			String scollege, String sbeiyong01, String sbeiyong02) {
		this.sname = sname;
		this.snumber = snumber;
		this.ssex = ssex;
		this.sage = sage;
		this.sclass = sclass;
		this.snativeplace = snativeplace;
		this.snation = snation;
		this.scollege = scollege;
		this.sbeiyong01 = sbeiyong01;
		this.sbeiyong02 = sbeiyong02;
	}

	// Property accessors

	public Long getSid() {
		return this.sid;
	}

	public void setSid(Long sid) {
		this.sid = sid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSnumber() {
		return this.snumber;
	}

	public void setSnumber(String snumber) {
		this.snumber = snumber;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSage() {
		return this.sage;
	}

	public void setSage(String sage) {
		this.sage = sage;
	}

	public String getSclass() {
		return this.sclass;
	}

	public void setSclass(String sclass) {
		this.sclass = sclass;
	}

	public String getSnativeplace() {
		return this.snativeplace;
	}

	public void setSnativeplace(String snativeplace) {
		this.snativeplace = snativeplace;
	}

	public String getSnation() {
		return this.snation;
	}

	public void setSnation(String snation) {
		this.snation = snation;
	}

	public String getScollege() {
		return this.scollege;
	}

	public void setScollege(String scollege) {
		this.scollege = scollege;
	}

	public String getSbeiyong01() {
		return this.sbeiyong01;
	}

	public void setSbeiyong01(String sbeiyong01) {
		this.sbeiyong01 = sbeiyong01;
	}

	public String getSbeiyong02() {
		return this.sbeiyong02;
	}

	public void setSbeiyong02(String sbeiyong02) {
		this.sbeiyong02 = sbeiyong02;
	}

}