package cn.hiber.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;

import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;
import cn.hiber.service.StuService;
import cn.hiber.service.UserService;

/**
 * Servlet implementation class StuServlet
 */
@WebServlet("/StuServlet")
public class StuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
    private StuService stuService = new StuService(); 
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=Utf-8");
		
		request.setCharacterEncoding("UTF-8");
		
		String action = request.getParameter("action");
		
		if("addStu".equals(action)) {
			String sname = request.getParameter("sname");
			String snumber = request.getParameter("snumber");
			String ssex = request.getParameter("ssex");
			String sage = request.getParameter("sage");
			String snation = request.getParameter("snation");
			String snativeplace = request.getParameter("snativeplace");
			String scollege = request.getParameter("scollege");
			String sclass = request.getParameter("sclass");
			
			
			HttpSession session = request.getSession();
			
			StudentInfo stu = new StudentInfo(sname,snumber,ssex,sage,sclass,snativeplace,snation,scollege,"","");

			boolean result = stuService.addStuent(stu);
			
			int r = 0;
			if(result == true) {
				r = 1;
				response.sendRedirect("../addStuRes.jsp?res="+r);
			} else {
				response.sendRedirect("../addStuRes.jsp?res="+r);
			}
			
		} else if("findStuBySname".equals(action)) {
			String sname = request.getParameter("sname");
			HttpSession session = request.getSession();
			
			String msg = null;
			StudentInfo stu = stuService.findStuBySname(sname);
			
			if(stu == null) {
				msg = "findStuBySnameError";
				response.sendRedirect(String.format("../findStuBySname.jsp?msg=%s",msg));
			} else {
				request.setAttribute("stu", stu);
				RequestDispatcher rd = request.getRequestDispatcher("../findStuBySnameRes.jsp");
				rd.forward(request, response);
			}
		} else if("findAllStu".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			request.setAttribute("listStu", listStu);
			RequestDispatcher rd = request.getRequestDispatcher("../findAllStuRes.jsp");
			rd.forward(request, response);
		} else if("updateStu".equals(action)) {
			String sname = request.getParameter("sname");
			HttpSession session = request.getSession();
			
			String msg = null;
			StudentInfo stu = stuService.findStuBySname(sname);
			
			if(stu == null) {
				msg = "findStuBySnameError";
				response.sendRedirect(String.format("../updateStu.jsp?msg=%s",msg));
			} else {
				request.setAttribute("stu", stu);
				RequestDispatcher rd = request.getRequestDispatcher("../updateStuRes.jsp");
				rd.forward(request, response);
			}
		} else if("updateStuRes".equals(action)) {
			String sid = request.getParameter("sid");
			String sname = request.getParameter("sname");
			String snumber = request.getParameter("snumber");
			String ssex = request.getParameter("ssex");
			String sage = request.getParameter("sage");
			String snation = request.getParameter("snation");
			String snativeplace = request.getParameter("snativeplace");
			String scollege = request.getParameter("scollege");
			String sclass = request.getParameter("sclass");
			HttpSession session = request.getSession();
			
			String msg = null;
			
			StudentInfo stu = new StudentInfo(sname,snumber,ssex,sage,sclass,snativeplace,snation,scollege,"","");
			stu.setSid(Long.parseLong(sid));
			boolean result = stuService.updateStu(stu);
			
			if(result == true) {
				msg = "updateSuccess";
				response.sendRedirect(String.format("../updateStu.jsp?msg=%s",msg));
			} else {
				msg = "updateError";
				response.sendRedirect(String.format("../updateStu.jsp?msg=%s",msg));
			}
		}  else if("deleteStu".equals(action)) {
			String sname = request.getParameter("sname");
			HttpSession session = request.getSession();
			
			String msg = null;
			StudentInfo stu = stuService.findStuBySname(sname);
			
			if(stu == null) {
				msg = "findStuBySnameError";
				response.sendRedirect(String.format("../deleteStu.jsp?msg=%s",msg));
			} else {
//				request.setAttribute("stu", stu);
//				RequestDispatcher rd = request.getRequestDispatcher("updateStuRes.jsp");
//				rd.forward(request, response);
				boolean deleteStuRes = stuService.deleteStu(stu);
				if(deleteStuRes == true) {
					msg = "deleteSuccess";
					response.sendRedirect(String.format("../deleteStu.jsp?msg=%s",msg));
				} else {
					msg = "deleteError";
					response.sendRedirect(String.format("../deleteStu.jsp?msg=%s",msg));
				}
			}
		} else if("findStuBySnumber".equals(action)) {
			String snumber = request.getParameter("snumber");
			HttpSession session = request.getSession();
			
			String msg = null;
			StudentInfo stu = stuService.findStuBySnumber(snumber);
			
			if(stu == null) {
				msg = "findStuBySnumberError";
				response.sendRedirect(String.format("../findStuBySnumber.jsp?msg=%s",msg));
			} else {
				request.setAttribute("stu", stu);
				RequestDispatcher rd = request.getRequestDispatcher("../findStuBySnameRes.jsp");
				rd.forward(request, response);
			}
		} else if("analStuBySage".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			
			String categoriesFlag[] = new String[listStu.size()];
			for(int i = 0;i < listStu.size();i++) {
				categoriesFlag[i] = listStu.get(i).getSage();
			}
			
			//ȥ���ظ�ֵ
			List<String> list = new ArrayList<String>();    
			    for (int i=0; i<categoriesFlag.length; i++) {    
			        if(!list.contains(categoriesFlag[i])) {    
			            list.add(categoriesFlag[i]);    
			        }    
			    }
			
			String categories[] =  new String[list.size()];
			for(int i = 0;i < list.size();i++) {
				categories[i] = list.get(i);
			}
			
			Arrays.sort(categories); 
			
			int[] data =  new int[categories.length];
			for(int i = 0; i < categories.length;i++) {
				data[i] = 0;
				for(int j = 0; j < listStu.size(); j++) {
					if(categories[i].equals(listStu.get(j).getSage())) {
						data[i] = data[i]+1;
					}
				}
			}

			request.setAttribute("categories", categories);
			request.setAttribute("stuData", data);
			
			RequestDispatcher rd = request.getRequestDispatcher("../analStuBySageRes.jsp");
			rd.forward(request, response);
		}  else if("analStuBySsex".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			
			int man = 0;
			int woman = 0;
			for(int i = 0; i < listStu.size();i++) {
				if(listStu.get(i).getSsex().equals("��")) {
					man += 1;
				} else if(listStu.get(i).getSsex().equals("Ů")) {
					woman += 1;
				}
			}
			int[] data = {man,woman};
			request.setAttribute("man", man);
			request.setAttribute("woman", woman);
			RequestDispatcher rd = request.getRequestDispatcher("../analStuBySsexRes.jsp");
			rd.forward(request, response);
		}  else if("analStuByScollege".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			
			String categoriesFlag[] = new String[listStu.size()];
			for(int i = 0;i < listStu.size();i++) {
				categoriesFlag[i] = listStu.get(i).getScollege();
			}
			
			//ȥ���ظ�ֵ
			List<String> list = new ArrayList<String>();    
			    for (int i=0; i<categoriesFlag.length; i++) {    
			        if(!list.contains(categoriesFlag[i])) {    
			            list.add(categoriesFlag[i]);    
			        }    
			    }
			
			String categories[] =  new String[list.size()];
			for(int i = 0;i < list.size();i++) {
				categories[i] = list.get(i);
			}
			
			Arrays.sort(categories); 
			
			int[] data =  new int[categories.length];
			for(int i = 0; i < categories.length;i++) {
				data[i] = 0;
				for(int j = 0; j < listStu.size(); j++) {
					if(categories[i].equals(listStu.get(j).getScollege())) {
						data[i] = data[i]+1;
					}
				}
			}

			request.setAttribute("categories", categories);
			request.setAttribute("stuData", data);
			
			RequestDispatcher rd = request.getRequestDispatcher("../analStuByScollegeRes.jsp");
			rd.forward(request, response);
		}  else if("analStuBySnation".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			
			String categoriesFlag[] = new String[listStu.size()];
			for(int i = 0;i < listStu.size();i++) {
				categoriesFlag[i] = listStu.get(i).getSnation();
			}
			
			//ȥ���ظ�ֵ
			List<String> list = new ArrayList<String>();    
			    for (int i=0; i<categoriesFlag.length; i++) {    
			        if(!list.contains(categoriesFlag[i])) {    
			            list.add(categoriesFlag[i]);    
			        }    
			    }
			
			String categories[] =  new String[list.size()];
			for(int i = 0;i < list.size();i++) {
				categories[i] = list.get(i);
			}
			
			Arrays.sort(categories); 
			
			int[] data =  new int[categories.length];
			for(int i = 0; i < categories.length;i++) {
				data[i] = 0;
				for(int j = 0; j < listStu.size(); j++) {
					if(categories[i].equals(listStu.get(j).getSnation())) {
						data[i] = data[i]+1;
					}
				}
			}

			request.setAttribute("categories", categories);
			request.setAttribute("stuData", data);
			
			RequestDispatcher rd = request.getRequestDispatcher("../analStuBySnationRes.jsp");
			rd.forward(request, response);
		}  else if("analStuBySnativeplace".equals(action)) {
			List<StudentInfo> listStu = new ArrayList<StudentInfo>();
			listStu = stuService.findAllStu();
			
			String categoriesFlag[] = new String[listStu.size()];
			for(int i = 0;i < listStu.size();i++) {
				categoriesFlag[i] = listStu.get(i).getSnativeplace();
			}
			
			//ȥ���ظ�ֵ
			List<String> list = new ArrayList<String>();    
			    for (int i=0; i<categoriesFlag.length; i++) {    
			        if(!list.contains(categoriesFlag[i])) {    
			            list.add(categoriesFlag[i]);    
			        }    
			    }
			
			String categories[] =  new String[list.size()];
			for(int i = 0;i < list.size();i++) {
				categories[i] = list.get(i);
			}
			
			Arrays.sort(categories); 
			
			int[] data =  new int[categories.length];
			for(int i = 0; i < categories.length;i++) {
				data[i] = 0;
				for(int j = 0; j < listStu.size(); j++) {
					if(categories[i].equals(listStu.get(j).getSnativeplace())) {
						data[i] = data[i]+1;
					}
				}
			}

			request.setAttribute("categories", categories);
			request.setAttribute("stuData", data);
			
			RequestDispatcher rd = request.getRequestDispatcher("../analStuBySnativeplaceRes.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
