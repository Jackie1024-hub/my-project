package cn.hiber.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;
import cn.hiber.service.UserService;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	private UserService userService = new UserService(); 
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=Utf-8");
		
		request.setCharacterEncoding("UTF-8");

		String msg = null;
		
		String action = request.getParameter("action");
		
		if("doLogin".equals(action)) {
			String uname = request.getParameter("uname");
			String upassword = request.getParameter("upassword");
			String valideCode = request.getParameter("inputCode");//��֤��
			
			HttpSession session = request.getSession();
			
			if(valideCode.equals(session.getAttribute("numrand"))) {
				UserInfo user = new UserInfo(uname,upassword);
				UserInfo loginUser = userService.login(user);
				System.out.println(uname+"    "+upassword);
				
			if(loginUser != null && loginUser.getUname() != null) {
				String unameString = URLEncoder.encode(uname, "UTF-8");
				
				System.out.println(loginUser.getUname());
				request.setAttribute("user", user);
				request.setAttribute("uid", String.valueOf(loginUser.getUid()));
				request.setAttribute("uname", loginUser.getUname());
				request.setAttribute("upassword", loginUser.getUpassword());
				RequestDispatcher rd = request.getRequestDispatcher("../index.jsp");
				rd.forward(request, response);
//				response.sendRedirect(String.format("index.jsp?uname=%s", unameString));
				
			} else {
				msg = "loginError";
				response.sendRedirect(String.format("../login.jsp?msg=%s",msg));
			}
			} else {
				msg = "validateCodeError";
				response.sendRedirect(String.format("../login.jsp?msg=%s",msg));
			}
		} else if("doRegister".equals(action)) {
			String uname = request.getParameter("uname");
			String upassword = request.getParameter("upassword");
			UserInfo user = new UserInfo(uname, upassword);
			
			boolean result = userService.register(user);
			if(result == true) {
				response.sendRedirect("../login.jsp");
			} else {
				response.sendRedirect("../register.jsp");
			}
		} else if("updateUser".equals(action)) {
			String uid = request.getParameter("uid");
			String uname = request.getParameter("uname");
			String upassword = request.getParameter("upassword");
			HttpSession session = request.getSession();
			
//			String msg = null;
			System.out.println(uid);
			UserInfo user = new UserInfo(uname, upassword);
			user.setUid(Long.parseLong(uid));
			boolean result = userService.updateUser(user);
			if(result == true) {
				msg = "updateSuccess";
//				PrintWriter out = response.getWriter();
//				out.println("<html>"); 
//				out.println("<script>"); 
//				out.println("alert('�޸ĳɹ���');");
//				out.println("window.open ('login','_top')"); 
//				out.println("</script>"); 
//				out.println("</html>");
				response.sendRedirect(String.format("../updateUser.jsp?msg=%s",msg));
			} else {
				msg = "updateError";
				response.sendRedirect(String.format("../updateUser.jsp?msg=%s",msg));
			}
		}
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
