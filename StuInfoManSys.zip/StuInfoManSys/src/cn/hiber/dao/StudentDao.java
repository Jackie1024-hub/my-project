package cn.hiber.dao;

import java.util.List;

import cn.hiber.entity.StudentInfo;

public interface StudentDao {
	
	public boolean addStu(StudentInfo studentinfo);
	public boolean deleteStu(StudentInfo studentinfo);
	public boolean updateStu(StudentInfo studentinfo);
	
	public List<StudentInfo> findAllStu();
	
	public StudentInfo findStuBySname(String sname);
	
	public StudentInfo findStuBySnumber(String snumber);
	
	public StudentInfo getStu(Long Sid);

}
