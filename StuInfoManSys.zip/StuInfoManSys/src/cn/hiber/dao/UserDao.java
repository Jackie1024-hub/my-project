package cn.hiber.dao;

import java.util.List;

import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;

public interface UserDao {
	
	public boolean addUser(UserInfo userinfo);
	public boolean deleteUser(UserInfo userinfo);
	public boolean updateUser(UserInfo userinfo);
	
	public List<UserInfo> findAllUser();
	public List<UserInfo> findUser(UserInfo user);
	
	public UserInfo getUser(Long Uid);

}
