package cn.hiber.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import cn.hiber.dao.StudentDao;
import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;
import cn.hiber.utils.HibernateSessionFactory;


public class StudentDaoImpl implements StudentDao {

	@Override
	//����ѧ����Ϣ
	public boolean addStu(StudentInfo studentinfo) {
		Transaction tx = null;
		try {
			//��hibernate��������
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			//��ѧ����Ϣ����
			session.save(studentinfo);

			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//ɾ��ѧ����Ϣ
	public boolean deleteStu(StudentInfo studentinfo) {
		Transaction tx = null;
		try {
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			session.delete(studentinfo);
			
			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//�޸�ѧ����Ϣ
	public boolean updateStu(StudentInfo studentinfo) {
		Transaction tx = null;
		try {
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			session.update(studentinfo);
			
			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//��ѯ����ѧ����Ϣ
	public List<StudentInfo> findAllStu() {
		List<StudentInfo> list = new ArrayList<StudentInfo>();
		try {
			Session session = HibernateSessionFactory.getSession();
			Query query = session.createQuery("from StudentInfo");
			list = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		
		return list;
	}
	
	//��������ѯѧ����Ϣ
		public StudentInfo findStuBySname(String sname){
			try {
				Session session = HibernateSessionFactory.getSession();
				String queryString= "from StudentInfo where sname ='" + sname +"'";
				return (StudentInfo) session.createQuery(queryString).uniqueResult();
			} catch (HibernateException e) {
				e.printStackTrace();
			} finally {
				HibernateSessionFactory.closeSession();
			}
			return null;
		}
		
		//��������ѯѧ����Ϣ
		public StudentInfo findStuBySnumber(String snumber){
			try {
				Session session = HibernateSessionFactory.getSession();
				String queryString= "from StudentInfo where snumber ='" + snumber +"'";
				return (StudentInfo) session.createQuery(queryString).uniqueResult();
			} catch (HibernateException e) {
				e.printStackTrace();
			} finally {
				HibernateSessionFactory.closeSession();
			}
			return null;
		}

	@Override
	//��id��ѯѧ����Ϣ
	public StudentInfo getStu(Long Sid) {
		try {
			Session session = HibernateSessionFactory.getSession();
			return (StudentInfo) session.get(StudentInfo.class, Sid);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return null;
	}

}
