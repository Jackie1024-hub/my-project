package cn.hiber.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import cn.hiber.dao.UserDao;
import cn.hiber.entity.StudentInfo;
import cn.hiber.entity.UserInfo;
import cn.hiber.utils.HibernateSessionFactory;

public class UserDaoImpl implements UserDao {

	@Override
	//�����û�
	public boolean addUser(UserInfo userinfo) {
		Transaction tx = null;
		try {
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			session.save(userinfo);
			
			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//ɾ���û�
	public boolean deleteUser(UserInfo userinfo) {
		Transaction tx = null;
		try {
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			session.delete(userinfo);
			
			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//�����û���Ϣ
	public boolean updateUser(UserInfo userinfo) {
		Transaction tx = null;
		try {
			Session session = HibernateSessionFactory.getSession();
			tx = session.beginTransaction();
			
			session.update(userinfo);
			
			tx.commit();
			return true;
		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return false;
	}

	@Override
	//��ѯȫ���û�
	public List<UserInfo> findAllUser() {
		List<UserInfo> list = new ArrayList<UserInfo>();
		try {
			Session session = HibernateSessionFactory.getSession();
//			Query query = session.createQuery("from userdb");
//			list = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		
		return list;
	}
	
	//��ѯ�û�
	public List<UserInfo> findUser(UserInfo user){
		List<UserInfo> list = new ArrayList<UserInfo>();
		try {
			Session session = HibernateSessionFactory.getSession();
			
			Criteria criteria = session.createCriteria(UserInfo.class);	
			criteria.add(Example.create(user));
			
			list = criteria.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return list;
	}

	@Override
	//��id��ѯ�û�
	public UserInfo getUser(Long Uid) {
		try {
			Session session = HibernateSessionFactory.getSession();
			return (UserInfo) session.get(UserInfo.class, Uid);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			HibernateSessionFactory.closeSession();
		}
		return null;
	}
	

}
