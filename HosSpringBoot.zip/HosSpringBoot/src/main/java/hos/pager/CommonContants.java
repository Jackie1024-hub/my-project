package hos.pager;

public class CommonContants {
	/** CTRL+SHIFT+Y --> Сд
	 *  CTRL+SHIFT+X --> ��д
	 *  ��֤��
	 * */
	public static final String VERIFY_SESSION = "verify_session";
}
