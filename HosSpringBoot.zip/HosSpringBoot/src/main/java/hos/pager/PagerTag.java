package hos.pager;
import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class PagerTag  extends SimpleTagSupport {
	/** ��������URL�е�ռλ������ */
	private static final String TAG = "{0}";
	
	/** ��ǰҳ�� */
	private int pageIndex;
	/** ÿҳ��ʾ������ */
	private int pageSize;
	/** �ܼ�¼���� */
	private int recordCount;
	/** ����URL page.action?pageIndex={0}*/
	private String submitUrl;
	
	/** ������ҳ�� */
	private int totalPage = 0;
	
	/**  ��ҳ���������Զ����ǩ�ͻᴥ��һ����ǩ������   */
	@Override
	public void doTag() throws JspException, IOException {
		/** ������ƴ�����յĽ�� */
		StringBuilder res = new StringBuilder();
		
		res.append("<center>\n" +
                "\t\t<p style=\"text-align: center;\">\n" +
                "\t\t\t<!-- ��Ƶ���-->\n" +
                "\t\t\t<nav class=\"nav form-inline\">\n" +
                "\t\t\t\t <ul class=\"pagination alin\">");
		/** ������ƴ���м��ҳ�� */
		StringBuilder str = new StringBuilder();
		/** �ж��ܼ�¼���� */
		if (recordCount > 0){   //1499 / 15  = 100
			/** ��Ҫ��ʾ��ҳ��ǩ���������ҳ�� ��Ҫ�ֶ���ҳ */
			totalPage = (this.recordCount - 1) / this.pageSize + 1; 
			
			/** �ж���һҳ����һҳ�費��Ҫ��a��ǩ */
			if (this.pageIndex == 1){ // ��ҳ
				str.append("<li class=\"disabled\" ><a href=\"#\">��һҳ</a></li>");
				
				/** �����м��ҳ�� */
				this.calcPage(str);
				
				/** ��һҳ�費��Ҫa��ǩ */
				if (this.pageIndex == totalPage){
					/** ֻ��һҳ */
					str.append("<li class=\"disabled\" ><a href=\"#\">��һҳ</a></li>");
				}else{
					String tempUrl = this.submitUrl.replace(TAG, String.valueOf(pageIndex + 1));
					str.append("<li><a href='"+tempUrl+"'>��һҳ</a></li>");
				}
			}else if (this.pageIndex == totalPage){ // βҳ
				String tempUrl = this.submitUrl.replace(TAG, String.valueOf(pageIndex - 1));
				str.append("<li><a href='"+tempUrl+"'>��һҳ</a></li>");
				
				/** �����м��ҳ�� */
				this.calcPage(str);
				
				str.append("<li class=\"disabled\" ><a href=\"#\">��һҳ</a></li>");
			}else{ // �м�
				String tempUrl = this.submitUrl.replace(TAG, String.valueOf(pageIndex - 1));
				str.append("<li><a href='"+tempUrl+"'>��һҳ</a></li>");
				
				/** �����м��ҳ�� */
				this.calcPage(str);
				
				tempUrl = this.submitUrl.replace(TAG, String.valueOf(pageIndex + 1));
				str.append("<li><a href='"+tempUrl+"'>��һҳ</a></li>");
			}
			
			res.append(str);
			
			/** ��ʼ���� */
			int startNum = (this.pageIndex - 1) * this.pageSize + 1;
			/** �������� */
			int endNum = (this.pageIndex == this.totalPage) ? this.recordCount : this.pageIndex * this.pageSize;
           
			res.append("<li><a style=\"background-color:#D4D4D4;\" href=\"#\">��<font color='red'>"+this.recordCount+"</font>����¼,��ǰ��ʾ"+startNum+"-"+endNum+"����¼</a>&nbsp;</li>");
			
			 res.append("<div class=\"input-group\">\n" +
	                    "\t\t\t\t\t\t\t\t\t      <input id='pager_jump_page_size' value='"+this.pageIndex+"' type=\"text\" style=\"width: 60px;text-align: center;\" class=\"form-control\" placeholder=\""+this.pageIndex+"\"\">\n" +
	                    "\t\t\t\t\t\t\t\t\t      <span class=\"input-group-btn\">\n" +
	                    "\t\t\t\t\t\t\t\t\t        <button class=\"btn btn-info\" id='pager_jump_btn' type=\"button\">GO</button>\n" +
	                    "\t\t\t\t\t\t\t\t\t      </span>\n" +
	                    "\t\t\t\t\t   \t\t\t\t </div>");
			
			res.append("<script type='text/javascript'>");
			res.append("   document.getElementById('pager_jump_btn').onclick = function(){");
			res.append("      var page_size = document.getElementById('pager_jump_page_size').value;");
			res.append("      if (!/^[1-9]\\d*$/.test(page_size) || page_size < 1 || page_size > "+ this.totalPage +"){");
			res.append("          alert('������[1-"+ this.totalPage +"]֮���ҳ�룡');");
			res.append("      }else{");
			res.append("         var submit_url = '" + this.submitUrl + "';");
			res.append("         window.location = submit_url.replace('"+ TAG +"', page_size);");
			res.append("      }");
			res.append("}");
			res.append("</script>");
			
			
		}else{
            res.append("<li><a style=\"background-color:#D4D4D4;\" href=\"#\">�ܹ�<font color='red'>0</font>����¼,��ǰ��ʾ0-0����¼��</a>&nbsp;</li>");
		}
		
		res.append("</ul></nav></p></center>");
		this.getJspContext().getOut().print(res.toString());
	}
	
	
	/** �����м�ҳ��ķ��� */
	private void calcPage(StringBuilder str) {
		/** �ж���ҳ�� */
		if (this.totalPage <= 11){
			/** һ������ʾȫ����ҳ�� */
			for (int i = 1; i <= this.totalPage; i++){
				if (this.pageIndex == i){
					/** ��ǰҳ�� */
					str.append("<li class=\"active\" ><a href=\"#\">"+i+"</a></li>");
				}else{
					String tempUrl = this.submitUrl.replace(TAG, String.valueOf(i));
					str.append("<li><a href='"+tempUrl+"'>"+i+"</a></li>");
				}
			}
		}else{
			/** ����ҳ��Щ  */
			if (this.pageIndex <= 8){
				for (int i = 1; i <= 10; i++){
					if (this.pageIndex == i){
						/** ��ǰҳ�� */
						str.append("<li class=\"active\" ><a href=\"#\">"+i+"</a></li>");
					}else{
						String tempUrl = this.submitUrl.replace(TAG, String.valueOf(i));
						str.append("<li><a href='"+tempUrl+"'>"+i+"</a></li>");
					}
				}
				str.append("<li><a href=\"#\">...</a></li>");
				String tempUrl = this.submitUrl.replace(TAG, String.valueOf(this.totalPage));
				str.append("<li><a href='"+tempUrl+"'>"+this.totalPage+"</a></li>");
				
			}
			/** ��βҳ��Щ  */
			else if (this.pageIndex + 8 >= this.totalPage){
				String tempUrl = this.submitUrl.replace(TAG, String.valueOf(1));
				str.append("<li><a href='"+tempUrl+"'>1</a></li>");
				str.append("<li><a href=\"#\">...</a></li>");
				
				for (int i = this.totalPage - 10; i <= this.totalPage; i++){
					if (this.pageIndex == i){
						/** ��ǰҳ�� */
						str.append("<li class=\"active\" ><a href=\"#\">"+i+"</a></li>");
					}else{
						tempUrl = this.submitUrl.replace(TAG, String.valueOf(i));
						str.append("<li><a href='"+tempUrl+"'>"+i+"</a></li>");
					}
				}
			}
			/** ���м� */
			else{
				String tempUrl = this.submitUrl.replace(TAG, String.valueOf(1));
				str.append("<li><a href='"+tempUrl+"'>1</a></li>");
				str.append("<li><a href=\"#\">...</a></li>");
				
				for (int i = this.pageIndex - 4; i <= this.pageIndex + 4; i++){
					if (this.pageIndex == i){
						/** ��ǰҳ�� */
						str.append("<li class=\"active\" ><a href=\"#\">"+i+"</a></li>");
					}else{
						tempUrl = this.submitUrl.replace(TAG, String.valueOf(i));
						str.append("<li><a href='"+tempUrl+"'>"+i+"</a></li>");
					}
				}
				
				str.append("<li><a href=\"#\">...</a></li>");
				tempUrl = this.submitUrl.replace(TAG, String.valueOf(this.totalPage));
				str.append("<li><a href='"+tempUrl+"'>"+this.totalPage+"</a></li>");
			}
		}
	}

	/** setter method */
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public void setSubmitUrl(String submitUrl) {
		this.submitUrl = submitUrl;
	}
}
