package hos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import hos.domain.Medi;

public interface MediRepository extends JpaRepository<Medi, String> , JpaSpecificationExecutor<Medi>{
	//MediRepository�Ƕ�ҩƷ�Ĳ�������Ҫ�Ǽ̳�Jpa��jpa�л�������ɾ�Ĳ鹦��
	Medi findByname(String name);
	
//	Medi findStockkByname(String name);
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value = "update hos_id_medi set stockk=?1 where name=?2",nativeQuery = true)
	public void updateMedi(int stockk, String name);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value = "update hos_id_medi set ingg=?1, proo=?2, spe=?3, type=?4, ind=?5, usagee=?6, usageed=?7, stockk=?8 where name=?9",nativeQuery = true)
	public void updateMediAll(String ingg,String proo,String spe,String type,String ind,String usagee,String usageed,int stockk, String name);
}
