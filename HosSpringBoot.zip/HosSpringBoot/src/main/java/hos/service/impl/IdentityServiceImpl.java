package hos.service.impl;

import hos.service.IdentityService;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
//import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.management.RuntimeErrorException;
//import java.util.Map.Entry;
//
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.JoinType;
//import javax.persistence.criteria.Path;
//import javax.persistence.criteria.Predicate;
//import javax.persistence.criteria.Root;
import javax.servlet.http.HttpSession;

import hos.pager.CommonContants;
import hos.pager.PageModel;
import hos.domain.Medi;
import hos.domain.User;
//import org.fkit.oa.identity.dto.UserModule;
import hos.repository.MediRepository;
import hos.repository.UserRepository;

import hos.vo.TreeData;
import net.sf.json.JSONArray;
import hos.utl.HosContants;
//import org.fkit.oa.util.OaException;
import hos.utl.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
@Service("IdentityService") // ����ҵ����bean

@Transactional(readOnly=true)
public class IdentityServiceImpl implements IdentityService {
	
	@Autowired  // bytype
	@Qualifier("userRepository") // byName
	private UserRepository userRepository;
	
	@Autowired  // bytype
	@Qualifier("mediRepository") // byName
	private MediRepository mediRepository;
	

	@Override
	public Map<String , Object> login(Map<String, Object> params) {
		Map<String , Object> result = new HashMap<>();
		try {
			/** ������¼��ҵ���߼�   */
			/** 1.�����ǿ�У��  */
			String userId = (String) params.get("userId");
			String passWord = (String) params.get("passWord");
			String vcode = (String) params.get("vcode");
			HttpSession session = (HttpSession) params.get("session");
			// userId!=null&&!userId.equals("")
			if(StringUtils.isEmpty(userId) || StringUtils.isEmpty(passWord)
					|| StringUtils.isEmpty(vcode) ){
				/** ������Ϊ�յ� */
				result.put("status", 0);
				result.put("tip", "������Ϊ�յ�");
			}else{
				/** ������Ϊ��  */
				/** У����֤���Ƿ���ȷ 
				 *  ��ȡsession�е�ǰ�û���Ӧ����֤�� 
				 * */
				String sysCode = (String) session.getAttribute(CommonContants.VERIFY_SESSION);
				if(vcode.equalsIgnoreCase(sysCode)){
					/** ��֤����ȷ��  */
					/** ���ݵ�¼���û���ȥ��ѯ�û�: �жϵ�¼���Ƿ����  */
					User user = getUserById(userId);
					if(user!=null){
						/** ��¼������  */
						/** �ж����� */
						if(user.getPassWord().equals(passWord)){
							 /** �ж��û��Ƿ��Ѿ��������� */
							if(user.getStatus() == 1){
								/** ��¼�ɹ�  */
								/** 1.�ѵ�¼�ɹ����û����뵱ǰ�û���session�Ự��  */
								session.setAttribute(HosContants.USER_SESSION, user);
								System.out.println("�����û� ---------------->��" + user);
								result.put("status",1);
								result.put("tip", "��¼�ɹ�");
								/** �ѵ�¼�ɹ����û����뵽UserHolder*/
								UserHolder.addCurrentUser(user);
								/** 2.���û�һ��¼����ϵͳ��ʱ��,��Ӧ������ȥ��ѯ���û���ӵ��
	      									��ȫ������Ȩ�� --> ���뵽��ǰ�û���Session�Ự��  */
//								Map<String,List<String>> userAllOperasPopedomUrls = getUserAllOperasPopedomUrls();
//								session.setAttribute(HosContants.USER_ALL_OPERAS_POPEDOM_URLS, userAllOperasPopedomUrls);
										
 							}else{
								result.put("status",5);
								result.put("tip", "�����˺�δ������,����ϵ����Ա����!");
							}
						}else{
							/** �������     */
							result.put("status", 2);
							result.put("tip", "���������");
						}
					}else{
						/** ��¼��������  */
						result.put("status", 3);
						result.put("tip", "û�и��˻�");
					}
				}else{
					/** ��֤�벻��ȷ */
					result.put("status", 4);
					result.put("tip", "��֤�벻��ȷ");
				}
			}
			return result;
		} catch (Exception e) {
			//throw new OaException("�첽��¼ҵ����׳��쳣��", e);
			return null;
		}
		
		
	}

	

	public User getUserById(String userId) {
		try {
			System.out.println("11111111111    "+userId);
			User user = userRepository.findOne(userId);
			if(user != null){
				// ��ȡ�ӳټ��ص�����
				
				return user;
			}
		    return null ;
		} catch (Exception e) {
			//throw new OaException("��ѯ�û�ʧ����", e);
			return null ;
		}
	}
	
	@Transactional
	@Override
	public void updateSelf(User user,HttpSession session) {
		try {
			/** 1.�־û��޸�   */
			User sessionUser = userRepository.findOne(user.getUserId());
			
			sessionUser.setName(user.getName());
			sessionUser.setPassWord(user.getPassWord());
			sessionUser.setSex(user.getSex());
			sessionUser.setEmail(user.getEmail());
			sessionUser.setTel(user.getTel());
			sessionUser.setPhone(user.getPhone());

			sessionUser.setQqNum(user.getQqNum());
			// getһ�¾Ϳ��Լ����ӳټ��ص�����
			//if(sessionUser.getDept()!=null)sessionUser.getDept().getName();
			//if(sessionUser.getJob()!=null)sessionUser.getJob().getName();
			session.setAttribute(HosContants.USER_SESSION, sessionUser);
		} catch (Exception e) {
			//throw new OaException("�޸��û�ʧ����", e);
			System.out.println(e);
		}
		
	}
    
	
	
//	@SuppressWarnings("serial")
//	@Override
//	public List<User> getUsersByPager(User user, PageModel pageModel) {
//		try {
//			Page<User> usersPager = userRepository.findAll(new Specification<User>() {
//				@Override
//				public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query,
//						CriteriaBuilder cb) {
//					// ���������ڷ�װ��ѯ����
//					List<Predicate> predicates = new ArrayList<Predicate>();  
//					if(user!=null){
//						/** �Ƿ�������������ѯ  */
//						if(!StringUtils.isEmpty(user.getName())){
//							predicates.add(cb.like(root.<String> get("name"),"%" + user.getName() + "%"));
//						}
//						/** �Ƿ����ֻ�����������ѯ  */
//						if(!StringUtils.isEmpty(user.getPhone())){
//							predicates.add(cb.like(root.<String> get("phone"),"%" + user.getPhone() + "%"));
//						}
//						
//					}
//					return query.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
//				}
//			},PageRequest.of(pageModel.getPageIndex() - 1, pageModel.getPageSize()));
////					PageRequest.of(pageModel.getPageIndex() - 1, pageModel.getPageSize()));
//			pageModel.setRecordCount(usersPager.getTotalElements());
//			/** ȡÿ���û����ӳټ������� */
//			List<User> users = usersPager.getContent();
////			for(User u : users){
////				if(u.getDept()!=null)u.getDept().getName();
////				if(u.getJob()!=null)u.getJob().getName();
////				if(u.getChecker()!=null)u.getChecker().getName();
////			}
//			return users;
//		} catch (Exception e) {
////			throw new OaException("��ѯ�û���Ϣ�쳣��", e);
//		}
//	}
	
	@Transactional
	@Override
	public void deleteUserByUserIds(String ids) {
		try {
			List<User> users = new ArrayList<User>();
			for(String id : ids.split(",")){
				User user = new User() ;
				user.setUserId(id);
				users.add(user);
			}
			userRepository.deleteInBatch(users);
		} catch (Exception e) {
//			throw new OaException("ɾ���û���Ϣ�쳣��", e);
		}
	}
	
	@Override
	public String isUserValidAjax(String userId) {
		try {
			User user = userRepository.findOne(userId);
			return user==null?"success":"error";
		} catch (Exception e) {
//			throw new OaException("У���û���¼���Ƿ�ע���쳣��", e);
			return null;
		}
	}
	
	@Transactional
	@Override
	public void addUser(User user) {
		try {
		    user.setCreateDate(new Date());
//		    user.setCreater(UserHolder.getCurrentUser());
		    userRepository.save(user);
		} catch (Exception e) {
//			throw new OaException("�����û���Ϣ�쳣��", e);
		}
		
	}
	
	@Transactional
	@Override
	public void updateUser(User user) {
		try {
			/** 1.�־û��޸�   */
			User sessionUser = userRepository.findOne(user.getUserId());
	
			sessionUser.setPassWord(user.getPassWord());
			sessionUser.setName(user.getName());
			
			sessionUser.setEmail(user.getEmail());
			sessionUser.setSex(user.getSex());
			sessionUser.setTel(user.getTel());
			sessionUser.setPhone(user.getPhone());
			
			sessionUser.setQqNum(user.getQqNum());
		} catch (Exception e) {
			//throw new OaException("�޸��û�ʧ����", e);
		}
	}
	
	@Transactional
	@Override
	public void activeUser(User user) {
//		try {
//			User sessionUser = userRepository.findById(user.getUserId()).get();
//			sessionUser.setCheckDate(new Date());
//			sessionUser.setChecker(UserHolder.getCurrentUser());
//			sessionUser.setStatus(user.getStatus());
//		} catch (Exception e) {
//			throw new OaException("�����û�ʧ����", e);
//		}
		
	}
	


	@Override
	public Map<String, Object> getAllDeptsAndJobsAjax() {
		// TODO Auto-generated method stub
		return null;
	}



	@Transactional
	@Override
	public void addMedi(Medi medi,Model model) {
		// TODO Auto-generated method stub
		try {
			Medi medd = mediRepository.findByname(medi.getName());
			
			if(medd!=null){
				System.out.println(medd.getName());
				model.addAttribute("tip", "ҩƷ�Ѵ��ڣ�����ʧ�ܣ�");
			}else {
		    mediRepository.save(medi);
		    model.addAttribute("tip", "���ӳɹ���");
			}
		} catch (Exception e) {
			model.addAttribute("tip", "����ʧ�ܣ�");
		}
	}
	
	@Transactional
	@Override
	public void deleMedi(Medi medi,Model model,HttpSession session) {
		// TODO Auto-generated method stub
		try {
			Medi medd = mediRepository.findByname(medi.getName());
			
			if(medd==null){
				model.addAttribute("tip", "ҩƷ�����ڣ���ȡʧ�ܣ�");
			}else {

				int meddnum = medd.getStockk();
				int medinum = medi.getStockk();
				
		    if(meddnum < medinum) {

		    	model.addAttribute("tip", "��治������ȡʧ�ܣ�");
		    }else {
		    	int sessionStockk = medi.getStockk();

		    	medi.setStockk(medd.getStockk() - sessionStockk);
		    	System.out.println(medi.getStockk());
//		    	session.setAttribute(HosContants.MEDI_SESSION, medi);
//		    	mediRepository.updateMedi(medi);
		    	mediRepository.updateMedi(medi.getStockk(),medi.getName());
		    	model.addAttribute("tip", "��ȡ�ɹ���");
		    }
			}
		} catch (Exception e) {
			System.out.println(e);
			model.addAttribute("tip", "��ȡʧ�ܣ�");
		}
	}



	@Transactional
	@Override
	public void xiuMedi(Medi medi, Model model, HttpSession session) {
		// TODO Auto-generated method stub
		try {
			Medi medd = mediRepository.findByname(medi.getName());
			
			if(medd==null){
				model.addAttribute("tip", "ҩƷ�����ڣ��޸Ŀ��ʧ�ܣ�");
			}else {
				String name = medi.getName();
				int stockk = medi.getStockk();
		    	mediRepository.updateMedi(stockk,name);
		    	model.addAttribute("tip", "�޸Ŀ��ɹ���");
			}
		} catch (Exception e) {
			System.out.println(e);
			model.addAttribute("tip", "�޸Ŀ��ʧ�ܣ�");
		}
	}



	@Transactional
	@Override
	public Medi updateMediSearch(Medi medi, Model model, HttpSession session) {
		// TODO Auto-generated method stub
		try {
			Medi medd = mediRepository.findByname(medi.getName());
			if(medd==null){
				model.addAttribute("tip", "ҩƷ�����ڣ�");
				return null;
			}else {
				session.setAttribute(HosContants.MEDI_SESSION,medd);
				return medd;
			}
		} catch (Exception e) {
			model.addAttribute("tip", "����ʧ�ܣ�");
			return null;
		}
	}



	@Transactional
	@Override
	public void updateMedi(Medi medi, Model model, HttpSession session) {
		// TODO Auto-generated method stub
		try {
			Medi medd = mediRepository.findByname(medi.getName());
			System.out.println("2222222222   "+medi.getName());
			if(medd==null){
				model.addAttribute("tip", "ҩƷ�����ڣ��޸�ʧ�ܣ�");
			}else {
				String name = medi.getName();
		    	mediRepository.updateMediAll(medi.getIngg(),medi.getProo(),medi.getSpe(),medi.getType(),medi.getInd(),medi.getUsagee(),medi.getUsageed(),medi.getStockk(),name);
		    	session.setAttribute(HosContants.MEDI_SESSION,medi);
		    	model.addAttribute("tip", "�޸ĳɹ���");
			}
		} catch (Exception e) {
			System.out.println(e);
			model.addAttribute("tip", "�޸�ʧ�ܣ�");
		}
	}


	@Transactional
	@Override
	public void analMediByType( HttpSession session) {
		List<Medi> mediList = new ArrayList<Medi>();
		mediList = mediRepository.findAll();
		JSONArray data = JSONArray.fromObject(mediList);
		session.setAttribute("data", data);
//       System.out.println(data.get(0));
	}
}
