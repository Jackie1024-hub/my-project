package hos.utl;

public class HosContants {
	/**
	 *  �û�session 
	 */
	public static final String USER_SESSION = "user_session";
	
	public static final String MEDI_SESSION = "medi_session";
	
	/**
	 *  ���벽��
	 */
	public static final int CODE_LEN = 4;

	/**
	 *  �û��Ĳ���Ȩ�޵�ַsession
	 */
	public static final String USER_ALL_OPERAS_POPEDOM_URLS = "user_all_operas_popedom_urls";

	/**
	 *  ģ�����Ȩ�� 
	 */
	public static final String MODULE_OPERAS_POPEDOM_URLS = "moduleOperasUrls";
}
