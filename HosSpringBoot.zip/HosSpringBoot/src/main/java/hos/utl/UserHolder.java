package hos.utl;
import hos.domain.User;
public class UserHolder {
	/** ����һ��ThreadLocal �洢��ǰĳ�������̶߳�Ӧ�ĵ�½�û�   */
	private static ThreadLocal<User> users = new ThreadLocal<>();
	
	public static void addCurrentUser(User user){
		if(users.get()== null){
			users.set(user);
		}
	}
	
	public static User getCurrentUser(){
		return users.get();
	}

	public static void removeCurrentUser() {
		users.remove();
	}
}
