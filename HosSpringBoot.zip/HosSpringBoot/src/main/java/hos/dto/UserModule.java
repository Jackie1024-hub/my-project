package hos.dto;
import java.util.ArrayList;
import java.util.List;
public class UserModule {
	/** һ��ģ�� */
//	private Module firstModule;
//	/** ����ģ�� */
//	private List<Module> secondModules = new ArrayList<>();
//	
//	public Module getFirstModule() {
//		return firstModule;
//	}
//	public void setFirstModule(Module firstModule) {
//		this.firstModule = firstModule;
//	}
//	public List<Module> getSecondModules() {
//		return secondModules;
//	}
//	public void setSecondModules(List<Module> secondModules) {
//		this.secondModules = secondModules;
//	}
}
