package hos.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity 
@Table(name="HOS_ID_Ware")
public class Warehouse  implements Serializable {
	private static final long serialVersionUID = -3417930882448168081L;
	/** ID	PK����СдӢ�ĺ����� */
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="WAREE_ID")
	private Integer WareeId;
	
	/** �ֿ�� */
	@Column(name="WAREID", length=200)
	private String wareId;
	
	/** �ֿ����� */
	@Column(name="WARENAME", length=200)
	private String wareName;
	
	/** �ֿ���� */
	@Column(name="WAREAREA", length=200)
	private String wareArea;
	
	/** ������Ա */
	@Column(name="WAREMANA", length=200)
	private String wareMana;
	
	/** setter and getter method */
	public String getWareId() {
		return wareId;
	}
	public void setWareId(String wareId) {
		this.wareId = wareId;
	}
	
	public String getWareArea() {
		return wareArea;
	}
	public void setWareArea(String wareArea) {
		this.wareArea = wareArea;
	}
	public String getWareMana() {
		return wareMana;
	}
	public void setWareMana(String wareMana) {
		this.wareMana = wareMana;
	}
	
}

