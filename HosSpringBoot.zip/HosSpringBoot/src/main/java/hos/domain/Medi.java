package hos.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity 
@Table(name="HOS_ID_MEDI")
public class Medi  implements Serializable {
	private static final long serialVersionUID = -3417930882448168081L;
	/** �û�ID	PK����СдӢ�ĺ����� */
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="MED_ID")
	private Integer medId;
	
	/** ���� */
	@Column(name="NAME", length=200)
	private String name;
	
	/** ��Ҫ�ɷ� */
	@Column(name="INGG", length=200)
	private String ingg;
	
	/** ��Ʒ��״ */
	@Column(name="PROO", length=200)
	private String proo;
	
	/** ��Ʒ��� */
	@Column(name="SPE", length=200)
	private String spe;
	
	/** ��Ӧ֢ */
	@Column(name="IND", length=200)
	private String ind;
	
	/** �÷����� */
	@Column(name="USAGEE", length=200)
	private String usagee;
	
	/** ��� */
	@Column(name="STOCKK", length=200)
	private Integer stockk;
	
	/** �ڷ������� */
	@Column(name="USAGEED", length=200)
	private String usageed;
	
	/** ����֢���� */
	@Column(name="TYPE", length=200)
	private String type;
	
	/** �ֿ�� */
	@Column(name="warehouseId", length=200)
	private String warehouseId;
	
	/** ��Ӧ�̺� */
	@Column(name="supplierId", length=200)
	private String supplierId;
	
	/** setter and getter method */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getIngg() {
		return ingg;
	}
	public void setIngg(String ingg) {
		this.ingg = ingg;
	}
	public String getProo() {
		return proo;
	}
	public void setProo(String proo) {
		this.proo = proo;
	}
	public String getSpe() {
		return spe;
	}
	public void setSpe(String spe) {
		this.spe = spe;
	}
	public String getInd() {
		return ind;
	}
	public void setInd(String ind) {
		this.ind = ind;
	}
	public String getUsagee() {
		return usagee;
	}
	public void setUsagee(String usagee) {
		this.usagee = usagee;
	}
	public Integer getStockk() {
		return stockk;
	}
	public void setStockk(Integer stockk) {
		this.stockk = stockk;
	}
	public String getUsageed() {
		return usageed;
	}
	public void setUsageed(String usageed) {
		this.usageed = usageed;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(String warehouseId) {
		this.warehouseId = warehouseId;
	}
	
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
}

