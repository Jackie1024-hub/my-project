package hos.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity 
@Table(name="HOS_ID_Supp")
public class Supplier  implements Serializable {
	private static final long serialVersionUID = -3417930882448168081L;
	/** ID	PK����СдӢ�ĺ����� */
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SUPP_ID")
	private Integer suppId;
	
	/** ��Ӧ�̺� */
	@Column(name="SUPID", length=200)
	private String supId;
	
	/** ���� */
	@Column(name="SUPNAME", length=200)
	private String supNmae;
	
	/** ��ַ */
	@Column(name="SUPADDRESS", length=200)
	private String supAddress;
	
	/** �绰�� */
	@Column(name="SUPPHONE", length=200)
	private String supPhone;
	
	/** �˺� */
	@Column(name="SUPACCOUNT", length=200)
	private String supAccount;
	
	
	/** setter and getter method */
	public String getSupId() {
		return supId;
	}
	public void setSupId(String supId) {
		this.supId = supId;
	}
	
	public String getSupNmae() {
		return supNmae;
	}
	public void setSupNmae(String supNmae) {
		this.supNmae = supNmae;
	}
	public String getSupAddress() {
		return supAddress;
	}
	public void setSupAddress(String supAddress) {
		this.supAddress = supAddress;
	}
	public String getSupPhone() {
		return supPhone;
	}
	public void setSupPhone(String supPhone) {
		this.supPhone = supPhone;
	}
	public String getSupAccount() {
		return supAccount;
	}
	public void setSupAccount(String supAccount) {
		this.supAccount = supAccount;
	}
	
}

