package hos.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity @Table(name="HOS_ID_USER", 
indexes={@Index(columnList="NAME", name="IDX_USER_NAME")})
public class User  implements Serializable {
	private static final long serialVersionUID = -3417930882448168081L;
	/** �û�ID	PK����СдӢ�ĺ����� */
	@Id @Column(name="USER_ID", length=50)
	private String userId;
	/** ����	MD5���� */	
	@Column(name="PASS_WORD", length=50)
	private String passWord;
	/** ���� */
	@Column(name="NAME", length=50)
	private String name;
	/** �Ա�	1:�� 2:Ů */
	@Column(name="SEX")
	private Short sex = 1;
	/** ���� */
	@Column(name="EMAIL", length=50)
	private String email;
	/** �绰���� */
	@Column(name="TEL", length=50)
	private String tel;
	/** �ֻ����� */
	@Column(name="PHONE", length=50)
	private String phone;
	/** QQ���� */
	@Column(name="QQ_NUM", length=50)
	private String qqNum;
	/** ״̬	0�½�,1���,2��ͨ�����,3����  */
	@Column(name="STATUS")
	private Short status = 0;
	/** ����ʱ�� */
	@Column(name="CREATE_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;
	/** �쵼 	0�����쵼,1�쵼 */
	@Column(name="LEADD")
	private Short leadd = 0;
	
	/** setter and getter method */
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Short getSex() {
		return sex;
	}
	public void setSex(Short sex) {
		this.sex = sex;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getQqNum() {
		return qqNum;
	}
	public void setQqNum(String qqNum) {
		this.qqNum = qqNum;
	}
	
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	public Short getLeadd() {
		return leadd;
	}
	public void setLeadd(Short leadd) {
		this.leadd = leadd;
	}
}
