package hos.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import hos.domain.User;
import hos.service.IdentityService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Resource // by type
	private IdentityService identityService;
	
	@RequestMapping(value="/updateUser")
	public String updateSelf(User user,Model model,HttpSession session){
		try {
			identityService.updateSelf(user,session);
			model.addAttribute("tip", "�޸ĳɹ���");
		} catch (Exception e) {
			model.addAttribute("tip", "�޸�ʧ�ܣ�");
			e.printStackTrace();
		}
		return "welcome";
	}
	
	
}
