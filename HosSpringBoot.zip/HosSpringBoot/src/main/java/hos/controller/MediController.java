package hos.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import hos.domain.Medi;
import hos.service.IdentityService;

@Controller
@RequestMapping("/medi")
public class MediController {
	@Resource // by type
	private IdentityService identityService;
	
	@RequestMapping(value="/addMedi")
	public String addMedi(Medi medi,Model model,HttpSession session){
//		try {
			identityService.addMedi(medi,model);
//			model.addAttribute("tip", "���ӳɹ���");
//		} catch (Exception e) {
//			model.addAttribute("tip", "����ʧ�ܣ�");
//			e.printStackTrace();
//		}
		return "addMediSearch";
	}
	
	@RequestMapping(value="/deleMedi")
	public String deleMedi(Medi medi,Model model,HttpSession session){
			identityService.deleMedi(medi,model,session);
		return "deleMediSearch";
	}
	
	@RequestMapping(value="/xiuMedi")
	public String xiuMedi(Medi medi,Model model,HttpSession session){
			identityService.xiuMedi(medi,model,session);
		return "xiuMediSearch";
	}
	
	@RequestMapping(value="/updateMediForm")
	public String updateMedi(Medi medi,Model model,HttpSession session){
		Medi medii = identityService.updateMediSearch(medi, model, session);
		if(medii == null) {
			return "updateMediSearch";
		}
		else {
			return "updateMedi";
		}
		
	}
	
	@RequestMapping(value="/updateMedi")
	public String updateMediSec(Medi medi,Model model,HttpSession session){
		identityService.updateMedi(medi, model, session);
		return "updateMedi";
	}
	
	@RequestMapping(value="/analMediByType")
	public String analMediByType(HttpSession session){
		identityService.analMediByType(session);
		return "analMediByType";
	}
	
	@RequestMapping(value="/analMediByZhong")
	public String analMediByZhong(HttpSession session){
		identityService.analMediByType(session);
		return "analMediByZhong";
	}
}
