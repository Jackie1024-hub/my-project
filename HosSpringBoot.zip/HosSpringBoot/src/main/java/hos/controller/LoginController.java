package hos.controller;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import hos.service.IdentityService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
@SpringBootApplication // Spring Boot��Ŀ�ĺ���ע�⣬��ҪĿ���ǿ����Զ�����
@Controller // ��������һ��SpringMVC��Controller������
@ComponentScan(basePackages = {"hos.service"})
@EnableJpaRepositories(basePackages = "hos.repository")
@EntityScan(basePackages = "hos.domain")
public class LoginController {
	/** 1.����ҵ������ */
	@Resource // by type
	private IdentityService identityService;
	
	@ResponseBody  // �첽�������Ӧ���
	@RequestMapping(value="/loginAjax",produces="application/json; charset=UTF-8")
	public Map<String, Object> login(@RequestParam("userId")String userId, 
			@RequestParam("passWord")String passWord 
			,@RequestParam("vcode")String vcode
			,HttpSession session){
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("userId", userId);
			params.put("passWord", passWord);
			params.put("vcode", vcode);
			params.put("session", session);
			// ��Ӧ���ݰ�,д��ȥ����
			Map<String, Object> result = identityService.login(params);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
}
