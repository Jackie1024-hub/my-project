package hos.controller;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import hos.dto.UserModule;
import hos.service.IdentityService;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

//@RequestMapping("/oa")
public class RequestController {
	/** 1.����ҵ������ */
	@Resource // by type
	private IdentityService identityService;
	
	@RequestMapping(value="/login")
	public String requestLogin(){
		System.out.println("��¼�ɹ��ˣ�");
		return "login";
	}
	
	
	@RequestMapping(value="/main")
	public String requestMain(Model model){
		try {
			//��ѯ����ǰ�û�ӵ�е�����ģ��Ȩ��
//			List<UserModule> userModules = identityService.getUserPopedomModules();
//			model.addAttribute("userPopedomModules", userModules);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "main";
	}
	
	@RequestMapping(value="/home")
	public String requestHome(){
		return "home";
	}
	
	@RequestMapping(value="/welcome")
	public String requestWelcome(){
		return "welcome";
	}
	
	@RequestMapping(value="/personInfo")
	public String requestPerson(){
		return "personInfo";
	}
	
	@RequestMapping(value="/updateInfo")
	public String requestUpdateInfo(){
		return "updateUser";
	}
	
	@RequestMapping(value="/logout")
	public String logout(HttpSession session){
		try {
			/** ע����ǰ�Ự */
			session.invalidate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/login";
	}
	
	@RequestMapping(value="/addMediSearch")
	public String requestAddMediSearch(){
		return "addMediSearch";
	}
	
	@RequestMapping(value="/deleMediSearch")
	public String requestDeleMediSearch(){
		return "deleMediSearch";
	}
	
	@RequestMapping(value="/xiuMediSearch")
	public String requestXiuMediSearch(){
		return "xiuMediSearch";
	}
	
	@RequestMapping(value="/updateMediSearch")
	public String requestUpdateMediSearch(){
		return "updateMediSearch";
	}
	
	@RequestMapping(value="/analMediByType")
	public String requestAnalMediByType(HttpSession session){
		return "analMediByType";
	}
}
