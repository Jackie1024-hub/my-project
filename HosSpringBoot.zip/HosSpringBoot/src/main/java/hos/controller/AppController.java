package hos.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppController  {
	
    public static void main( String[] args )
    {
    	// SpringApplication ���ڴ�main��������SpringӦ�õ��ࡣ
        SpringApplication.run(AppController.class, args);
    }
}
